//Clear variables from watch window
expRemoveAll()
//AddWatchWindowVars lab 2
expAdd ("LLC_buildLevel",getNatural())
expAdd ("LLC_board_Status.enum_boardStatus",getNatural())
expAdd ("LLC_startFlag",getNatural())
expAdd ("LLC_startupDutySlewFlag",getNatural())
expAdd ("LLC_vSec_Volts",getNatural())
expAdd ("LLC_iPriReso_Amps",getNatural())
expAdd ("LLC_iSec_Amps",getNatural())
expAdd ("LLC_vSecRef_debug_Volts",getNatural())
expAdd ("LLC_vSecRef_pu",getNatural())
expAdd ("EPwm1Regs.TZFLG",getNatural())
expAdd ("EPwm2Regs.TZFLG",getNatural())